<?php

namespace App\Http\Controllers\RAB;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProjectController extends Controller
{
    //
}

@extends('theme.default')

@section('breadcrumb')
			<div class="page-breadcrumb">
                <div class="row">
                    <div class="col-5 align-self-center">
                        <h4 class="page-title">Detail User</h4>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ URL::to('user') }}">User</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Detail</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
@endsection

@section('content')
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">
                                </h4>
                                
                                <form>
                                  @csrf
                                  @foreach($users as $key=>$value)
                                  <button class="btn btn-primary" type="button" data-toggle="modal" data-target="#passwordModal">Edit Password</button>
                                  <br><br>
                                  <!--href="{{ URL::to('user/edit_pass/'.$value->id) }}" -->
                                  <div class="form-row">
                                    <div class="col-md-12 mb-3">
                                      <label>Nama</label>
                                      <input type="text" class="form-control" name="nama" required value="{{$value->name}}">
                                      <div class="invalid-tooltip">
                                          Please fill out this field.
                                      </div>
                                    </div>
                                  </div>
                                  <div class="form-row">
                                    <div class="col-md-12 mb-3">
                                      <label>Email</label>
                                      <input type="text" class="form-control" name="nama" required value="{{$value->email}}">
                                      <div class="invalid-tooltip">
                                          Please fill out this field.
                                      </div>
                                    </div>
                                  </div>
                                  <div class="form-row">
                                    <div class="col-md-12 mb-3">
                                      <label>Role</label>
                                      <input type="text" class="form-control" name="nama" required value="{{$value->role_name}}">
                                      <div class="invalid-tooltip">
                                          Please fill out this field.
                                      </div>
                                    </div>
                                  </div>
                                  <div class="form-row">
                                    <div class="col-md-12 mb-3">
                                      <label>Role Code</label>
                                      <input type="text" class="form-control" name="nama" required value="{{$value->role_code}}">
                                      <div class="invalid-tooltip">
                                          Please fill out this field.
                                      </div>
                                    </div>
                                  </div>
                                  <button class="btn btn-primary mt-4" type="submit" disabled>Submit</button>
                                  <a href="{{ URL::to('user') }}" class="btn btn-danger mt-4">Batal</a>
                                  @endforeach
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
<div class="modal fade" id="passwordModal" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="post" action="{{ URL::to('user/edit_pass') }}">
            @csrf
                <div class="modal-header">
                    <h4 class="modal-title" id="modalAddWorkHeaderLabel1">Ganti Password</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="hidden" value="{{$id}}" name="id" class="form-control" required/>
                        <label class="control-label">Password:</label>
                        <input type="password" name="password" class="form-control" id="password" required autofocus />
                        <p id="textPass" style="color:red"></p>
                        <label class="control-label">Confirm Password:</label>
                        <input type="password" name="confirm" class="form-control" id="confirm" required onkeyup="cekConfirmPass()"/>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="btn_change" disabled class="btn btn-primary btn-sm">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    // function cekPass(){
    //     var pass=$('#password').val();
    //     if(pass.length()<10){
    //         $("#textPass").html("password kurang dari 10");
    //     }else{
    //         $("#textPass").html("password");
    //     }
        
    // }
    function cekConfirmPass(){
        var pass=$('#password').val();
        var confirm=$('#confirm').val();
        if(confirm == pass){
            $("#btn_change").attr("disabled", false);
        }else{
            $("#btn_change").attr("disabled", true);
        }
        
    }
</script>
@endsection
